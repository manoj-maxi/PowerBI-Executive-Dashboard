"""Generate realistic sample revenue data for the Executive Dashboard project."""
import csv, random, math
from datetime import date, timedelta

random.seed(42)

regions   = ["North America", "EMEA", "APAC", "LATAM"]
products  = ["Enterprise Suite", "Cloud Platform", "Analytics Add-on", "Support & Services", "Professional Services"]
segments  = ["Enterprise", "Mid-Market", "SMB"]
channels  = ["Direct", "Partner", "Online"]

# Seasonal + growth shaped monthly revenue, 2023-01 .. 2025-12
rows = []
inv = 100000
base = 1_800_000
for y in range(2023, 2026):
    for m in range(1, 13):
        # year-over-year growth ~12%, quarter-end seasonality bump
        growth = (1.12 ** (y - 2023))
        season = 1.0 + (0.18 if m in (3, 6, 9, 12) else 0.0) + 0.05 * math.sin(m / 12 * 2 * math.pi)
        month_target = base * growth * season
        # split target across dimension combos
        for region in regions:
            rweight = {"North America": 0.42, "EMEA": 0.28, "APAC": 0.20, "LATAM": 0.10}[region]
            for product in products:
                pweight = {"Enterprise Suite": 0.34, "Cloud Platform": 0.27,
                           "Analytics Add-on": 0.14, "Support & Services": 0.15,
                           "Professional Services": 0.10}[product]
                amt = month_target * rweight * pweight * random.uniform(0.85, 1.15)
                cost = amt * random.uniform(0.45, 0.68)
                budget = (base * growth * season) * rweight * pweight  # flat budget vs actual
                inv += 1
                rows.append({
                    "invoice_id": f"INV-{inv:06d}",
                    "date": date(y, m, min(28, random.randint(1, 28))).isoformat(),
                    "year": y, "month": m,
                    "year_month": f"{y}-{m:02d}",
                    "quarter": f"{y}-Q{(m-1)//3+1}",
                    "region": region,
                    "product": product,
                    "segment": random.choices(segments, weights=[0.5, 0.35, 0.15])[0],
                    "channel": random.choices(channels, weights=[0.55, 0.30, 0.15])[0],
                    "revenue": round(amt, 2),
                    "cost": round(cost, 2),
                    "budget": round(budget, 2),
                })

with open("data/revenue_data.csv", "w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
    w.writeheader()
    w.writerows(rows)

print(f"Wrote {len(rows):,} rows to data/revenue_data.csv")
total = sum(r["revenue"] for r in rows)
print(f"Total revenue across period: ${total:,.0f}")
