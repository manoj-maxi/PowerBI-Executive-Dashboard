# Report Design

## Page 1 — Executive Summary

```mermaid
flowchart TB
    subgraph Page["Executive Summary (single screen)"]
        K[KPI Row: Revenue · YoY · Margin · Budget Var · Top Product]
        T[Revenue vs Budget trend + 3M moving avg]
        R[Region donut]
        P[Product drill-through table]
        M[Margin % trend]
        S[Segment / Channel bars]
    end
    K --> T & R
    T --> P & M & S
```

Design principles applied:
- **F-pattern layout** — KPIs top-left to right, primary trend below, supporting visuals beneath.
- **One hero visual** — the revenue-vs-budget trend dominates; everything else supports it.
- **Conditional formatting** — KPI deltas color green/red; budget status uses 🟢🟡🔴.
- **Tabular numerics** — all currency uses tabular figures so columns align.

## Interactivity

| Feature | Implementation |
|---------|----------------|
| **Slicers** | Region, Product, Year (sync across visuals) |
| **Drill-through** | Right-click a product → "Product Detail" page, passes product context |
| **Cross-filtering** | Click a region slice → filters trend + product table |
| **Bookmarks** | "Reset filters" bookmark; "Forecast view" toggle |
| **Tooltips** | Custom report-page tooltip showing mini month trend per data point |
| **Dynamic title** | Page title reflects active slicer selections via a DAX title measure |

## Page 2 — Product Detail (drill-through target)

Filtered to the drilled product. Shows: monthly revenue trend, region mix, segment mix, channel mix, and rank vs other products. A "Back" button (bookmark) returns to summary.

## Page 3 — Forecast

- Combo chart: actuals (solid) + forecast (dashed) + confidence band (shaded area).
- DAX linear-regression forecast (`Forecast Revenue`) extended 6 months past last actual.
- Toggle between Revenue and Margin forecast via field parameter.

## Accessibility & polish

- High-contrast palette, color-blind-safe (blue/teal/orange, not red/green only — icons reinforce status).
- Alt text on visuals; tab order set for keyboard navigation.
- Mobile layout defined for the KPI row + trend.
