# Data Model

Star schema — one fact table at invoice grain, conformed dimensions, plus a budget fact at month/region/product grain.

```mermaid
erDiagram
    fact_sales }o--|| dim_date : date_key
    fact_sales }o--|| dim_region : region
    fact_sales }o--|| dim_product : product
    fact_sales }o--|| dim_segment : segment
    fact_sales }o--|| dim_channel : channel
    fact_budget }o--|| dim_date : date_key
    fact_budget }o--|| dim_region : region
    fact_budget }o--|| dim_product : product

    fact_sales {
        string invoice_id
        int date_key FK
        string region FK
        string product FK
        string segment FK
        string channel FK
        decimal revenue
        decimal cost
    }
    fact_budget {
        int date_key FK
        string region FK
        string product FK
        decimal budget_amount
    }
    dim_date {
        int date_key PK
        date date
        int year
        string quarter
        string year_month
    }
```

## Modeling notes
- **dim_date** marked as date table for time intelligence.
- Single-direction filters from dims → facts.
- Both `fact_sales` and `fact_budget` filtered by the shared `dim_date`, `dim_region`, `dim_product` — enabling actual-vs-budget on the same axes.
- Budget is at a coarser grain (month/region/product) than sales (invoice); measures aggregate sales up to match before variance.
- A disconnected `KPISelector` table powers dynamic measure switching.
